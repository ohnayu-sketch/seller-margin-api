# 🔧 적용 가이드 — 트렌드 소싱 + 마켓 대량 등록

## 파일 목록 (신규 4개)

| 파일 | 위치 | 설명 |
|------|------|------|
| `js/t1-trend.js` | 프론트 | T1 트렌드 소싱 모드 |
| `js/t5-market-register.js` | 프론트 | T5 마켓 대량 자동 등록 |
| `css/t1-trend-t5-register.css` | 프론트 | 위 두 모듈 CSS |
| `Code_additions.gs` | GAS | 서버측 API 함수 6개 |

---

## 1. seller-dashboard-v6.html 수정

### 1-1. CSS 링크 추가 (L36 부근, 기존 CSS 아래)

```html
<link rel="stylesheet" href="css/t1-trend-t5-register.css">
```

### 1-2. JS 스크립트 추가 (L841 부근, t5-studio.js 뒤)

```html
<script src="js/t1-trend.js"></script>
<script src="js/t5-market-register.js"></script>
```

### 1-3. T1 모드 버튼에 "트렌드 소싱" 추가

**파일 위치:** L179~185 부근

**변경 전:**
```html
<div style="margin-left:auto;display:flex;gap:4px;">
    <button class="t1-mode-btn active" data-mode="single" onclick="t1SetMode('single')">단건 검색</button>
    <button class="t1-mode-btn" data-mode="bulk" onclick="t1SetMode('bulk')">대량 소싱</button>
</div>
```

**변경 후:**
```html
<div style="margin-left:auto;display:flex;gap:4px;">
    <button class="t1-mode-btn active" data-mode="single" onclick="t1SetMode('single')">단건 검색</button>
    <button class="t1-mode-btn" data-mode="bulk" onclick="t1SetMode('bulk')">대량 소싱</button>
    <button class="t1-mode-btn" data-mode="trend" onclick="t1SetMode('trend')" style="background:rgba(16,185,129,0.12);border-color:rgba(16,185,129,0.3);">📈 트렌드 소싱</button>
</div>
```

### 1-4. T1 트렌드 패널 추가

**위치:** L263 `</div>` (t1-bulk-panel 닫힘) 바로 아래에 삽입

```html
    <!-- ═══ 트렌드 소싱 모드 ═══ -->
    <div id="t1-trend-panel" style="display:none;">
        <div class="t1-section-header">
            <span>📈 네이버 데이터랩 트렌드 소싱</span>
            <span class="t1-badge-new">TREND</span>
        </div>
        <div style="font-size:11px;color:#94a3b8;margin-bottom:10px;line-height:1.5;">
            카테고리별 검색량 급상승 키워드를 자동 추출하여<br>
            도매 가격 비교 → 마진 분석 → T5 상세페이지 대기열까지 원클릭 소싱합니다.
        </div>

        <!-- 카테고리 선택 그리드 -->
        <div id="t1-trend-cat-grid" class="t1-trend-cat-grid"></div>

        <!-- 급상승 키워드 + 분석 결과 -->
        <div id="t1-trend-results" style="display:none;"></div>
    </div>
```

### 1-5. T5 마켓 등록 패널 추가

**위치:** L527 `<div id="t5-queue-panel"...>` 바로 아래에 삽입

```html
    <!-- 마켓 대량 자동 등록 패널 (t5-market-register.js) -->
    <div id="t5-register-panel" class="t5-panel" style="display:none;"></div>
```

---

## 2. Code.gs 수정

### 2-1. doPost 라우터에 case 추가

기존 `doPost(e)` 함수의 switch/case 또는 if/else 분기에 추가:

```javascript
// ── 트렌드 소싱 ──
case 'datalabCategories':    return datalabCategories(body);
case 'datalabTrending':      return datalabTrending(body);
case 'datalabKeywordDetail': return datalabKeywordDetail(body);

// ── 스마트스토어 커머스 API ──
case 'smartstoreAuth':       return smartstoreAuth(body);
case 'smartstoreRegister':   return smartstoreRegister(body);
case 'smartstoreCategory':   return smartstoreCategory(body);
```

### 2-2. Code_additions.gs의 모든 함수를 Code.gs 하단에 복사

> 주의: `_jsonResponse()` 함수가 기존 Code.gs에 이미 있으면 중복 제거하세요.

### 2-3. 스크립트 속성 설정

GAS 에디터 → 프로젝트 설정 → 스크립트 속성에 추가:

| 속성명 | 설명 | 발급처 |
|--------|------|--------|
| `NAVER_CLIENT_ID` | 네이버 개발자 Client ID | https://developers.naver.com |
| `NAVER_CLIENT_SECRET` | 네이버 개발자 Client Secret | 동일 |
| `SMARTSTORE_CLIENT_ID` | 스마트스토어 커머스 API ID | https://apicenter.commerce.naver.com |
| `SMARTSTORE_CLIENT_SECRET` | 스마트스토어 커머스 API Secret | 동일 |

---

## 3. T7 설정 탭에 API 키 입력란 추가 (선택)

`js/t7-settings.js`에서 마켓 API 키 섹션에 스마트스토어 키 입력란이 없으면 추가:

```javascript
// T7 마켓 API 키 섹션에 추가
{
    label: '스마트스토어 Client ID',
    key: 'smartstore-client-id',
    placeholder: 'XXXXXXXXXXXXXXXX'
},
{
    label: '스마트스토어 Client Secret',
    key: 'smartstore-client-secret',
    placeholder: '$2a$...',
    type: 'password'
}
```

---

## 4. 동작 플로우

### 트렌드 소싱 (T1)
```
T1 → [📈 트렌드 소싱] 모드 클릭
→ 카테고리 그리드 표시 (패션/디지털/식품 등)
→ 카테고리 클릭 → GAS datalabTrending 호출
→ 급상승 TOP 20 키워드 렌더링
→ 키워드 클릭 → 시중가 조회 + 도매 검색 + 마진 분석
→ GO/WATCH/SKIP 신호 표시
→ GO 상품 체크 → [T5 대기열 전달] → T5로 이동
```

### 마켓 대량 등록 (T5)
```
T5 대기열 상품들의 상세페이지 생성 완료
→ [🚀 마켓 대량 자동 등록] 패널 자동 표시
→ 배송비/카테고리 설정
→ 각 상품의 카테고리 코드 검색/선택
→ [스마트스토어 일괄 등록] 클릭
→ GAS smartstoreRegister 순차 호출
→ 성공/실패 결과 실시간 표시
→ 실패 건 [재시도] 버튼
```

---

## 5. 주의사항

- **Sacred Zone 미침범**: MARKET_FEES, OAuth, dark theme 등 기존 코드 변경 없음
- **zero-cost 준수**: 모든 API 호출은 GAS 프록시 경유 (네트워크 무료)
- **기존 인터페이스 호환**: fetchGas, AppEventBus, showToast, fmt, fmtWon 등 기존 함수 재사용
- **에러 핸들링**: 데이터랩 API 실패 시 네이버 쇼핑 검색 기반 폴백 자동 전환
- **스마트스토어 토큰**: GAS CacheService에 캐시하여 불필요한 재발급 방지 (5.8시간 TTL)
