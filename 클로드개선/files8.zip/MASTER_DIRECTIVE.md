# 안티그래비티 실행 지시서 — 셀러 대시보드 v6→v7 전체 업그레이드
> 이 문서를 최상위 가이드로 삼아 순서대로 실행하라.
> 모든 신규 파일은 이 지시서와 함께 제공된다.
> 기존 파일 수정은 patches/ 폴더의 패치 지침을 따르라.

---

## Sacred Zone (절대 변경 금지)
- `AppConfig.MARKET_FEES` 8마켓 수수료 값
- Google OAuth (CLIENT_ID, handleCredentialResponse)
- 다크 테마 CSS 변수 (`--bg:#0d0f14`, `--surface:#1a1d24`, `--accent:#4ade80` 등)
- localStorage 키 구조
- JS 모듈 내부 변수 접두어 (t5-studio의 T5, t3-ledger의 t3, t4-finance의 t4, t6-oms의 t6)
- `fetchGas` / `AppEventBus` / `showToast` / `fmt` / `fmtWon` 함수 시그니처
- 구글 시트 ID: `1D6IlJquibWJfUkmIrKSz-PF4JYSa10dJd_GQdwtSSSg`

## 탭-모듈 매핑
| UI 라벨 | JS 모듈 | 내부변수 | page ID |
|---------|---------|---------|---------|
| T1 소싱 | t1-sourcing.js, t1-trend.js, **t1-feed.js(신규)** | T1, T1Trend, T1Feed | page-sourcing |
| T2 재고 | t2-inventory.js, t2-receiver.js | t2 | page-inventory |
| T3 스튜디오 | t5-studio.js, t5-market-register.js, **t5-image-auto.js(신규)** | T5, T5Register | page-studio |
| T4 OMS | t6-oms.js, **t6-kanban.js(신규)** | t6 | page-oms |
| T5 장부 | t3-ledger.js, **t3-auto-entry.js(신규)** | t3 | page-ledger |
| T6 재무 | t4-finance.js, **t4-tax.js(신규)** | t4 | page-finance |
| T7 설정 | t7-settings.js | t7 | page-setup |

## 용어 통일 규칙
| 기존 | 변경 | 코드 내 상수 |
|------|------|-------------|
| GO | 소싱추천 | SIGNAL_GO = '소싱추천' |
| WATCH | 지켜보기 | SIGNAL_WATCH = '지켜보기' |
| SKIP | 비추천 | SIGNAL_SKIP = '비추천' |

---

## 실행 순서

### PHASE 1: 공통 컴포넌트 + 버그 수정

**파일:** `js/core/ui-components.js` (신규)
**내용:** KPI 바 렌더러, 아코디언 컴포넌트, 알림 벨 드롭다운
**참조:** `js/ui-components.js` 제공 파일

**HTML 패치:** `patches/01-header-bell.patch`
- header `.header-right` 안에 알림 벨 아이콘 + 드롭다운 HTML 삽입
- sync-status 왼쪽에 배치

**HTML 패치:** `patches/02-bugfix.patch`
- L239: `id="t1-bulk-excel"` 제거 (id 중복)
- L703~704: `</div>` 위치 조정 (배너 버튼 DOM 오류)

**CSS:** `css/ui-components.css` (신규)
- KPI 바, 아코디언, 알림 벨 스타일

---

### PHASE 2: T1 소싱 전면 재설계

**HTML 패치:** `patches/03-t1-redesign.patch`
- page-sourcing 내부 전체 교체
- 좌측 고정 패널(260px) + 우측 트렌드 피드 레이아웃
- 모드 전환 버튼(단건/대량/트렌드) 제거
- 대량 소싱은 좌측 패널 하단 아코디언으로 이전

**파일:** `js/t1-feed.js` (신규)
**내용:**
- 트렌드 피드 초기 로드 (GAS `getTrendFeed` 호출)
- 상품 카드 렌더링 (테이블 정렬, 아이콘 버튼, 일치도 표시)
- 페이지네이션
- 필터/정렬
- 도매 비교 모달
- 카드 "담기" → `confirmSourcing()` 호출 (기존 event-bus.js)
- 카드 sendToStudio 직접 호출 제거 (T2 확정 후에만)
- 좌측 패널 급상승 키워드 TOP 20 / 카테고리 TOP 20 렌더링
- 검색바: 입력 시 트렌드 피드 → 검색 결과로 전환

**파일:** `js/t1-image-match.js` (신규)
**내용:**
- `matchProductImages(wholesaleItem, retailItem)` → Gemini Flash 멀티모달 호출
- 결과: `{ match: 'high'|'medium'|'low', reason }` 
- 카드에 일치도 뱃지 반영 (high→마진%, medium→추정마진%, low→직접확인)
- 대량 분석 시 배치 처리 (무료 티어 분당 15회 제한 준수)

**GAS 추가:** `gas/t1-additions.gs`
- `getTrendFeed(body)` — 데이터랩 급상승 + 도매 가격 비교 + 마진 분석 결합한 피드
- `geminiImageMatch(body)` — Gemini Flash로 이미지+상품명 비교
- `priceWatchdog()` + `priceWatchdogCron()` — 매일 09:00 시중가 재조회
- `trendWatchdog()` + `trendWatchdogCron()` — 매주 월 10:00 검색량 재조회
- `productSalesCount(body)` — 상품별 판매 건수 조회
- `getAlerts(body)` — 알림 탭 조회

**CSS:** `css/t1-feed.css` (신규)
- 좌측 패널, 상품 카드, 페이지네이션, 일치도 뱃지

---

### PHASE 3: T2 재고 파이프라인 강화

**HTML 패치:** `patches/04-t2-enhance.patch`
- `#t2-dashboard`에 KPI 바 + 리밸런싱 추천 카드 영역 추가
- FIFO/공급업체 패널을 아코디언 `<details>` 태그로 감싸기
- 확정 상품 카드에 "상세페이지 만들기" 버튼 HTML 추가

**t2-inventory.js 수정:**
- `t2RenderDashboard()` — KPI 바 렌더링 (총 상품수/판매중/재고자산/재주문필요)
- `t2RenderRebalance()` — 리밸런싱 추천 렌더링
- `t2RenderProductCard()` — 확정 상품에 "상세페이지 만들기" 버튼 추가
- 버튼 클릭 → `sendToStudio(item)` 호출
- `t2DeductStock(orderData)` — T4 주문 시 재고 차감
- `AppEventBus.on('ORDER_CONFIRMED', t2DeductStock)` 리스너 등록

**t1-sourcing.js 수정:**
- `renderProductCards()` 내 sendToStudio 버튼 HTML 제거
- `renderWholesaleCard()` 내 sendToStudio 버튼 HTML 제거

---

### PHASE 4: T3 스튜디오 이미지 자동화 + 레이아웃

**HTML 패치:** `patches/05-t3-redesign.patch`
- page-studio 내부 레이아웃 변경
- 이미지 입력란에 "자동 수집" 버튼 + "직접 첨부" 파일 업로드 버튼 추가
- STEP 1(필수) / STEP 2(스타일) / 고급 도구(아코디언) 구조 분리
- 우측 미리보기에 `position: sticky; top: 80px` 적용

**파일:** `js/t5-image-auto.js` (신규)
**내용:**
```
t5AutoFetchImages(productUrl, siteId)
  → fetchGas('scrapeProductImages', {url, siteId})
  → 성공: 이미지 URL을 #t5-image-urls에 자동 채움
  → 실패: "이미지를 가져오지 못했습니다" 메시지 + 파일 업로드 UI 표시

t5ManualUploadImage(file)
  → FileReader → base64
  → fetchGas('uploadImageToDrive', {base64Data, fileName})
  → 응답 URL을 #t5-image-urls에 추가

t5ReceiveFromT2(data)
  → 상품명, 판매가, 도매가, 도매처URL, 이미지URL 자동 채움
  → t5AutoFetchImages(도매처URL) 자동 실행
  → AI 카피 자동 트리거
```

**t5-studio.js 수정:**
- `t5ReceiveProduct(data)` — data.wholesaleUrl이 있으면 `t5AutoFetchImages` 호출
- `t5Init()`에 파일 업로드 이벤트 리스너 등록

**GAS 추가:** `gas/t3-additions.gs`
```
scrapeProductImages(body)
  body: { url, siteId }
  → API 지원 도매처: 해당 API로 이미지 목록 조회
  → API 미지원: UrlFetchApp(url) → HTML 파싱 → <img src="..."> 추출
  → 응답: { success, images: ['url1','url2',...] }

uploadImageToDrive(body)
  body: { base64Data, fileName }
  → DriveApp.createFile(blob) → 공유 설정 → URL 반환
  → 응답: { success, url }
```

---

### PHASE 5: T4 OMS 칸반 보드

**HTML 패치:** `patches/06-t4-kanban.patch`
- page-oms 내부 전체 교체
- KPI 바 + 칸반 4칼럼 + 주문 등록 아코디언 구조

**파일:** `js/t6-kanban.js` (신규)
**내용:**
```
T6Kanban.init()
  → 구글시트 "주문" 탭에서 주문 로드
  → 6단계 상태별 분류: 접수/발주확인/배송준비/배송중/배송완료/정산완료
  → 칸반 4칼럼 렌더링 (접수 | 발주확인 | 배송중 | 완료)
  → 카드 클릭 → 상태 전환 모달

T6Kanban.renderKPI()
  → 오늘 주문 / 처리 대기 / 배송중 / 이번달 매출

T6Kanban.advanceStatus(orderId, newStatus)
  → fetchGas('updateOrderStatus', {orderId, status})
  → 리렌더
  → 정산완료 시: AppEventBus.emit('ORDER_SETTLED', {금액,마켓,수수료,순이익})

T6Kanban.fetchMarketOrders()
  → fetchGas('fetchSmartstoreOrders', {})
  → 신규 주문 추가 + 알림
```

**GAS 추가:** `gas/t4-additions.gs`
```
fetchSmartstoreOrders(body) — 커머스 API 주문 조회
updateOrderStatus(body) — 주문 상태 업데이트
smartstoreUpdateTracking(body) — 운송장 등록
fetchOrdersCron() — 3시간마다 자동 수집 트리거
```

---

### PHASE 6: T5 장부 + T6 재무

**HTML 패치:** `patches/07-t5-ledger.patch`
- page-ledger 내부 개선
- KPI 바 + 마켓별 미니바 영역 추가
- 거래 입력 폼을 아코디언 + 2줄 구조로 변경
- 거래 목록을 카드형으로 변경

**파일:** `js/t3-auto-entry.js` (신규)
```
AppEventBus.on('ORDER_SETTLED', t3AutoIncome)
  → 수입 자동 기록 (태그: [자동])

AppEventBus.on('PRODUCT_STOCKED', t3AutoExpense)
  → 지출 자동 기록 (태그: [자동])

t3RenderKPI()
  → 이번달 수입/지출/순이익/전월대비 KPI 바

t3RenderMarketBars()
  → 마켓별 수입 가로 바 차트

t3MonthlyClose()
  → 구글시트 "월별정산" 탭에 월 요약 기록
```

**HTML 패치:** `patches/08-t6-finance.patch`
- page-finance 내부 개선
- 사업자 현황 카드 최상단 추가
- KPI 바 추가
- 매출 차트 풀와이드
- 분석 도구 아코디언

**파일:** `js/t4-tax.js` (신규)
```
t4RenderBusinessCard()
  → 과세유형 / 연누적매출 / 한도 프로그레스바 / 단계별 색상

t4CompareVatBenefit()
  → 간이 납부세액 vs 일반 납부세액 비교 계산
  → 어느 쪽이 유리한지 금액과 함께 표시

t4RenderProductROI()
  → 상품별 [소싱비용, 총매출, 순이익, ROI%] 테이블

t4EstimateCashFlow()
  → 3개월 이동평균 기반 다음달 예상 매출/지출/순이익
```

**GAS 추가:** `gas/t5-t6-additions.gs`
```
autoLedgerEntry(body) — 자동 거래 기록
getMonthlySettlement(body) — 월별 정산 조회
getAnnualSalesSummary(body) — 연 매출 요약
getProductROI(body) — 상품별 ROI 데이터
```

---

### PHASE 7: T7 설정 + 마무리

**HTML 패치:** `patches/09-t7-settings.patch`
- page-setup 내부 개선
- 시스템 상태 대시보드 최상단 추가
- 모든 패널을 `<details>` 아코디언으로 변경
- 마켓 API 키 확장 (쿠팡/11번가 입력란 추가)
- 알림 설정 패널 신규 추가
- 백업/복원 패널 신규 추가

**HTML 패치:** `patches/10-script-tags.patch`
- `</body>` 앞에 신규 JS 파일 스크립트 태그 추가
- `<head>`에 신규 CSS 링크 추가

**GAS 추가:** `gas/t7-additions.gs`
```
exportAllData(body) — 전체 시트 데이터 JSON 내보내기
importAllData(body) — JSON에서 시트 복원
```

**GAS:** `gas/setup-triggers.gs`
```
setupAllTriggers()
  → priceWatchdogCron: 매일 09:00
  → trendWatchdogCron: 매주 월 10:00
  → fetchOrdersCron: 3시간마다
```

**GAS:** `gas/doPost-router-additions.gs`
- 기존 doPost 라우터에 추가할 case 문 전체 목록

---

## 파일 체크리스트

### 신규 JS (7개)
- [ ] `js/core/ui-components.js` — KPI바, 아코디언, 알림벨
- [ ] `js/t1-feed.js` — T1 트렌드 피드 + 카드 렌더링
- [ ] `js/t1-image-match.js` — Gemini 이미지 매칭
- [ ] `js/t5-image-auto.js` — T3 이미지 자동 수집/수동 업로드
- [ ] `js/t6-kanban.js` — T4 칸반 보드
- [ ] `js/t3-auto-entry.js` — T5 자동 기록
- [ ] `js/t4-tax.js` — T6 세무 분석

### 신규 CSS (2개)
- [ ] `css/ui-components.css` — 공통 컴포넌트
- [ ] `css/t1-feed.css` — T1 피드 전용

### GAS 추가 (6개)
- [ ] `gas/t1-additions.gs`
- [ ] `gas/t3-additions.gs`
- [ ] `gas/t4-additions.gs`
- [ ] `gas/t5-t6-additions.gs`
- [ ] `gas/t7-additions.gs`
- [ ] `gas/setup-triggers.gs`
- [ ] `gas/doPost-router-additions.gs`

### HTML 패치 (10개)
- [ ] `patches/01-header-bell.patch`
- [ ] `patches/02-bugfix.patch`
- [ ] `patches/03-t1-redesign.patch`
- [ ] `patches/04-t2-enhance.patch`
- [ ] `patches/05-t3-redesign.patch`
- [ ] `patches/06-t4-kanban.patch`
- [ ] `patches/07-t5-ledger.patch`
- [ ] `patches/08-t6-finance.patch`
- [ ] `patches/09-t7-settings.patch`
- [ ] `patches/10-script-tags.patch`

### 기존 JS 수정 (2개)
- [ ] `t1-sourcing.js` — sendToStudio 버튼 제거
- [ ] `t2-inventory.js` — 확정 상품에 "상세페이지 만들기" 버튼 추가 + 재고 차감 리스너

### 구글시트 탭 추가 (5개)
- [ ] 가격추적
- [ ] 알림
- [ ] 주문
- [ ] 마켓등록
- [ ] 월별정산

### 스크립트 속성 확인
- [ ] NAVER_CLIENT_ID
- [ ] NAVER_CLIENT_SECRET
- [ ] SMARTSTORE_CLIENT_ID
- [ ] SMARTSTORE_CLIENT_SECRET
- [ ] GEMINI_API_KEY (프론트 localStorage에도 등록)

---

## 실행 완료 후 검증

1. T1 진입 → 트렌드 피드 상품 카드 로드 확인
2. 카드 "담기" → T2 대기열 수신 확인
3. T2 마진 확정 → "상세페이지 만들기" 버튼 표시 확인
4. T3 진입 → 이미지 자동 수집 시도 + 실패 시 수동 첨부 UI 확인
5. T4 칸반 렌더링 + 상태 전환 확인
6. T4 정산완료 → T5 자동 기록 확인
7. T6 사업자 현황 카드 + 매출 차트 확인
8. T7 아코디언 + 알림 벨 확인
9. 모바일(375px) 반응형 확인
10. PC(1400px) 좌측 패널 고정 확인
